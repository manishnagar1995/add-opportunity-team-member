declare module "@salesforce/schema/CustomBrand.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CustomBrand.Parent" {
  const Parent:any;
  export default Parent;
}
declare module "@salesforce/schema/CustomBrand.ParentId" {
  const ParentId:any;
  export default ParentId;
}
declare module "@salesforce/schema/CustomBrand.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CustomBrand.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CustomBrand.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CustomBrand.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/CustomBrand.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/CustomBrand.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
