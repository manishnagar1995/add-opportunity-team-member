declare module "@salesforce/schema/CaseSolution.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CaseSolution.Case" {
  const Case:any;
  export default Case;
}
declare module "@salesforce/schema/CaseSolution.CaseId" {
  const CaseId:any;
  export default CaseId;
}
declare module "@salesforce/schema/CaseSolution.Solution" {
  const Solution:any;
  export default Solution;
}
declare module "@salesforce/schema/CaseSolution.SolutionId" {
  const SolutionId:any;
  export default SolutionId;
}
declare module "@salesforce/schema/CaseSolution.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CaseSolution.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CaseSolution.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CaseSolution.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/CaseSolution.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
