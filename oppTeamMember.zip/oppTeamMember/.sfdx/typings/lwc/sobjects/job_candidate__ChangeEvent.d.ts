declare module "@salesforce/schema/job_candidate__ChangeEvent.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.ReplayId" {
  const ReplayId:string;
  export default ReplayId;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.ChangeEventHeader" {
  const ChangeEventHeader:any;
  export default ChangeEventHeader;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.Owner" {
  const Owner:any;
  export default Owner;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.OwnerId" {
  const OwnerId:any;
  export default OwnerId;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.DOB__c" {
  const DOB__c:any;
  export default DOB__c;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.id__c" {
  const id__c:string;
  export default id__c;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.job_experience__c" {
  const job_experience__c:number;
  export default job_experience__c;
}
declare module "@salesforce/schema/job_candidate__ChangeEvent.Age__c" {
  const Age__c:number;
  export default Age__c;
}
