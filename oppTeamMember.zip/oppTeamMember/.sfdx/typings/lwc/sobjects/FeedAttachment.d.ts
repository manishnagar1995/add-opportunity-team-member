declare module "@salesforce/schema/FeedAttachment.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/FeedAttachment.FeedEntity" {
  const FeedEntity:any;
  export default FeedEntity;
}
declare module "@salesforce/schema/FeedAttachment.FeedEntityId" {
  const FeedEntityId:any;
  export default FeedEntityId;
}
declare module "@salesforce/schema/FeedAttachment.Type" {
  const Type:string;
  export default Type;
}
declare module "@salesforce/schema/FeedAttachment.Record" {
  const Record:any;
  export default Record;
}
declare module "@salesforce/schema/FeedAttachment.RecordId" {
  const RecordId:any;
  export default RecordId;
}
declare module "@salesforce/schema/FeedAttachment.Title" {
  const Title:string;
  export default Title;
}
declare module "@salesforce/schema/FeedAttachment.Value" {
  const Value:string;
  export default Value;
}
declare module "@salesforce/schema/FeedAttachment.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
