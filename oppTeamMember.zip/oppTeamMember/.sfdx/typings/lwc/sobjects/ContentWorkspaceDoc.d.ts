declare module "@salesforce/schema/ContentWorkspaceDoc.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContentWorkspaceDoc.ContentWorkspace" {
  const ContentWorkspace:any;
  export default ContentWorkspace;
}
declare module "@salesforce/schema/ContentWorkspaceDoc.ContentWorkspaceId" {
  const ContentWorkspaceId:any;
  export default ContentWorkspaceId;
}
declare module "@salesforce/schema/ContentWorkspaceDoc.ContentDocument" {
  const ContentDocument:any;
  export default ContentDocument;
}
declare module "@salesforce/schema/ContentWorkspaceDoc.ContentDocumentId" {
  const ContentDocumentId:any;
  export default ContentDocumentId;
}
declare module "@salesforce/schema/ContentWorkspaceDoc.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ContentWorkspaceDoc.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/ContentWorkspaceDoc.IsOwner" {
  const IsOwner:boolean;
  export default IsOwner;
}
declare module "@salesforce/schema/ContentWorkspaceDoc.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
