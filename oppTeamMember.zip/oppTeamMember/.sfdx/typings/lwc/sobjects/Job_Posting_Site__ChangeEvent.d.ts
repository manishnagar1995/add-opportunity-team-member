declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.ReplayId" {
  const ReplayId:string;
  export default ReplayId;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.ChangeEventHeader" {
  const ChangeEventHeader:any;
  export default ChangeEventHeader;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.Owner" {
  const Owner:any;
  export default Owner;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.OwnerId" {
  const OwnerId:any;
  export default OwnerId;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.Job_Posting_Site_URL__c" {
  const Job_Posting_Site_URL__c:string;
  export default Job_Posting_Site_URL__c;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.Status__c" {
  const Status__c:string;
  export default Status__c;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.Technical_Site__c" {
  const Technical_Site__c:boolean;
  export default Technical_Site__c;
}
declare module "@salesforce/schema/Job_Posting_Site__ChangeEvent.Description__c" {
  const Description__c:string;
  export default Description__c;
}
