declare module "@salesforce/schema/IframeWhiteListUrl.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/IframeWhiteListUrl.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/IframeWhiteListUrl.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/IframeWhiteListUrl.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/IframeWhiteListUrl.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/IframeWhiteListUrl.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/IframeWhiteListUrl.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/IframeWhiteListUrl.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/IframeWhiteListUrl.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/IframeWhiteListUrl.Url" {
  const Url:string;
  export default Url;
}
