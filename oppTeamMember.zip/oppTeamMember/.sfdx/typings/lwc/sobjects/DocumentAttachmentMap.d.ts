declare module "@salesforce/schema/DocumentAttachmentMap.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/DocumentAttachmentMap.Parent" {
  const Parent:any;
  export default Parent;
}
declare module "@salesforce/schema/DocumentAttachmentMap.ParentId" {
  const ParentId:any;
  export default ParentId;
}
declare module "@salesforce/schema/DocumentAttachmentMap.Document" {
  const Document:any;
  export default Document;
}
declare module "@salesforce/schema/DocumentAttachmentMap.DocumentId" {
  const DocumentId:any;
  export default DocumentId;
}
declare module "@salesforce/schema/DocumentAttachmentMap.DocumentSequence" {
  const DocumentSequence:number;
  export default DocumentSequence;
}
declare module "@salesforce/schema/DocumentAttachmentMap.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/DocumentAttachmentMap.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/DocumentAttachmentMap.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
