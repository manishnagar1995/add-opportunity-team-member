declare module "@salesforce/schema/LightningExitByPageMetrics.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/LightningExitByPageMetrics.MetricsDate" {
  const MetricsDate:any;
  export default MetricsDate;
}
declare module "@salesforce/schema/LightningExitByPageMetrics.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/LightningExitByPageMetrics.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/LightningExitByPageMetrics.PageName" {
  const PageName:string;
  export default PageName;
}
declare module "@salesforce/schema/LightningExitByPageMetrics.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/LightningExitByPageMetrics.RecordCount" {
  const RecordCount:number;
  export default RecordCount;
}
