declare module "@salesforce/schema/KnowledgeableUser.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/KnowledgeableUser.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/KnowledgeableUser.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/KnowledgeableUser.Topic" {
  const Topic:any;
  export default Topic;
}
declare module "@salesforce/schema/KnowledgeableUser.TopicId" {
  const TopicId:any;
  export default TopicId;
}
declare module "@salesforce/schema/KnowledgeableUser.RawRank" {
  const RawRank:number;
  export default RawRank;
}
declare module "@salesforce/schema/KnowledgeableUser.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
