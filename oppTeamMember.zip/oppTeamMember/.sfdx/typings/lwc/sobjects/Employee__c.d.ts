declare module "@salesforce/schema/Employee__c.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/Employee__c.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/Employee__c.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/Employee__c.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/Employee__c.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/Employee__c.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/Employee__c.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/Employee__c.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/Employee__c.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/Employee__c.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/Employee__c.LastViewedDate" {
  const LastViewedDate:any;
  export default LastViewedDate;
}
declare module "@salesforce/schema/Employee__c.LastReferencedDate" {
  const LastReferencedDate:any;
  export default LastReferencedDate;
}
declare module "@salesforce/schema/Employee__c.Salary__c" {
  const Salary__c:number;
  export default Salary__c;
}
declare module "@salesforce/schema/Employee__c.Department__r" {
  const Department__r:any;
  export default Department__r;
}
declare module "@salesforce/schema/Employee__c.Department__c" {
  const Department__c:any;
  export default Department__c;
}
declare module "@salesforce/schema/Employee__c.Head_employee__r" {
  const Head_employee__r:any;
  export default Head_employee__r;
}
declare module "@salesforce/schema/Employee__c.Head_employee__c" {
  const Head_employee__c:any;
  export default Head_employee__c;
}
declare module "@salesforce/schema/Employee__c.Date_of_Joining__c" {
  const Date_of_Joining__c:any;
  export default Date_of_Joining__c;
}
