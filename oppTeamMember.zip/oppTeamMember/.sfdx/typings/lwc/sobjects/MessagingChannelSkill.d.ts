declare module "@salesforce/schema/MessagingChannelSkill.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/MessagingChannelSkill.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/MessagingChannelSkill.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/MessagingChannelSkill.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/MessagingChannelSkill.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/MessagingChannelSkill.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/MessagingChannelSkill.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/MessagingChannelSkill.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/MessagingChannelSkill.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/MessagingChannelSkill.MessagingChannel" {
  const MessagingChannel:any;
  export default MessagingChannel;
}
declare module "@salesforce/schema/MessagingChannelSkill.MessagingChannelId" {
  const MessagingChannelId:any;
  export default MessagingChannelId;
}
declare module "@salesforce/schema/MessagingChannelSkill.Skill" {
  const Skill:any;
  export default Skill;
}
declare module "@salesforce/schema/MessagingChannelSkill.SkillId" {
  const SkillId:any;
  export default SkillId;
}
