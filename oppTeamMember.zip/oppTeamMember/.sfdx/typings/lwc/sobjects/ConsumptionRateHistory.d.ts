declare module "@salesforce/schema/ConsumptionRateHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ConsumptionRateHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ConsumptionRateHistory.ConsumptionRate" {
  const ConsumptionRate:any;
  export default ConsumptionRate;
}
declare module "@salesforce/schema/ConsumptionRateHistory.ConsumptionRateId" {
  const ConsumptionRateId:any;
  export default ConsumptionRateId;
}
declare module "@salesforce/schema/ConsumptionRateHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ConsumptionRateHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ConsumptionRateHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ConsumptionRateHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/ConsumptionRateHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/ConsumptionRateHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
