declare module "@salesforce/schema/PackageSubscriber.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/PackageSubscriber.MetadataPackageVersion" {
  const MetadataPackageVersion:any;
  export default MetadataPackageVersion;
}
declare module "@salesforce/schema/PackageSubscriber.MetadataPackageVersionId" {
  const MetadataPackageVersionId:any;
  export default MetadataPackageVersionId;
}
declare module "@salesforce/schema/PackageSubscriber.InstalledStatus" {
  const InstalledStatus:string;
  export default InstalledStatus;
}
declare module "@salesforce/schema/PackageSubscriber.OrgKey" {
  const OrgKey:string;
  export default OrgKey;
}
declare module "@salesforce/schema/PackageSubscriber.OrgName" {
  const OrgName:string;
  export default OrgName;
}
declare module "@salesforce/schema/PackageSubscriber.OrgType" {
  const OrgType:string;
  export default OrgType;
}
declare module "@salesforce/schema/PackageSubscriber.OrgStatus" {
  const OrgStatus:string;
  export default OrgStatus;
}
declare module "@salesforce/schema/PackageSubscriber.InstanceName" {
  const InstanceName:string;
  export default InstanceName;
}
declare module "@salesforce/schema/PackageSubscriber.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/PackageSubscriber.ParentOrg" {
  const ParentOrg:string;
  export default ParentOrg;
}
