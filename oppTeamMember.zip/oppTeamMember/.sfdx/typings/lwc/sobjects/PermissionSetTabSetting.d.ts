declare module "@salesforce/schema/PermissionSetTabSetting.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/PermissionSetTabSetting.Parent" {
  const Parent:any;
  export default Parent;
}
declare module "@salesforce/schema/PermissionSetTabSetting.ParentId" {
  const ParentId:any;
  export default ParentId;
}
declare module "@salesforce/schema/PermissionSetTabSetting.Visibility" {
  const Visibility:string;
  export default Visibility;
}
declare module "@salesforce/schema/PermissionSetTabSetting.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/PermissionSetTabSetting.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
