declare module "@salesforce/schema/OpportunityFieldHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/OpportunityFieldHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/OpportunityFieldHistory.Opportunity" {
  const Opportunity:any;
  export default Opportunity;
}
declare module "@salesforce/schema/OpportunityFieldHistory.OpportunityId" {
  const OpportunityId:any;
  export default OpportunityId;
}
declare module "@salesforce/schema/OpportunityFieldHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/OpportunityFieldHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/OpportunityFieldHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/OpportunityFieldHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/OpportunityFieldHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/OpportunityFieldHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
