declare module "@salesforce/schema/MetadataPackage.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/MetadataPackage.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/MetadataPackage.NamespacePrefix" {
  const NamespacePrefix:string;
  export default NamespacePrefix;
}
declare module "@salesforce/schema/MetadataPackage.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
