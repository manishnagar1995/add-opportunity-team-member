declare module "@salesforce/schema/CustomObjectUserLicenseMetrics.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CustomObjectUserLicenseMetrics.MetricsDate" {
  const MetricsDate:any;
  export default MetricsDate;
}
declare module "@salesforce/schema/CustomObjectUserLicenseMetrics.UserLicense" {
  const UserLicense:any;
  export default UserLicense;
}
declare module "@salesforce/schema/CustomObjectUserLicenseMetrics.UserLicenseId" {
  const UserLicenseId:any;
  export default UserLicenseId;
}
declare module "@salesforce/schema/CustomObjectUserLicenseMetrics.CustomObjectId" {
  const CustomObjectId:string;
  export default CustomObjectId;
}
declare module "@salesforce/schema/CustomObjectUserLicenseMetrics.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/CustomObjectUserLicenseMetrics.CustomObjectType" {
  const CustomObjectType:string;
  export default CustomObjectType;
}
declare module "@salesforce/schema/CustomObjectUserLicenseMetrics.CustomObjectName" {
  const CustomObjectName:string;
  export default CustomObjectName;
}
declare module "@salesforce/schema/CustomObjectUserLicenseMetrics.ObjectCount" {
  const ObjectCount:number;
  export default ObjectCount;
}
