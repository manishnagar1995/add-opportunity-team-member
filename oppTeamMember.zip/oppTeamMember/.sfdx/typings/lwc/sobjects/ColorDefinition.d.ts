declare module "@salesforce/schema/ColorDefinition.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ColorDefinition.DurableId" {
  const DurableId:string;
  export default DurableId;
}
declare module "@salesforce/schema/ColorDefinition.TabDefinition" {
  const TabDefinition:any;
  export default TabDefinition;
}
declare module "@salesforce/schema/ColorDefinition.TabDefinitionId" {
  const TabDefinitionId:any;
  export default TabDefinitionId;
}
declare module "@salesforce/schema/ColorDefinition.Color" {
  const Color:string;
  export default Color;
}
declare module "@salesforce/schema/ColorDefinition.Theme" {
  const Theme:string;
  export default Theme;
}
declare module "@salesforce/schema/ColorDefinition.Context" {
  const Context:string;
  export default Context;
}
