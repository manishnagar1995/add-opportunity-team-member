declare module "@salesforce/schema/CronJobDetail.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CronJobDetail.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/CronJobDetail.JobType" {
  const JobType:string;
  export default JobType;
}
