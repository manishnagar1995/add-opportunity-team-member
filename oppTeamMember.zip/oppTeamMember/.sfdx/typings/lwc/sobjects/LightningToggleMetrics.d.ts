declare module "@salesforce/schema/LightningToggleMetrics.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/LightningToggleMetrics.MetricsDate" {
  const MetricsDate:any;
  export default MetricsDate;
}
declare module "@salesforce/schema/LightningToggleMetrics.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/LightningToggleMetrics.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/LightningToggleMetrics.Action" {
  const Action:string;
  export default Action;
}
declare module "@salesforce/schema/LightningToggleMetrics.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/LightningToggleMetrics.RecordCount" {
  const RecordCount:number;
  export default RecordCount;
}
