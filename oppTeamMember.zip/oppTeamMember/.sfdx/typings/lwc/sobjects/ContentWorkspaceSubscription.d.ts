declare module "@salesforce/schema/ContentWorkspaceSubscription.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContentWorkspaceSubscription.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/ContentWorkspaceSubscription.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/ContentWorkspaceSubscription.ContentWorkspace" {
  const ContentWorkspace:any;
  export default ContentWorkspace;
}
declare module "@salesforce/schema/ContentWorkspaceSubscription.ContentWorkspaceId" {
  const ContentWorkspaceId:any;
  export default ContentWorkspaceId;
}
