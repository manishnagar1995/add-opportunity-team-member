declare module "@salesforce/schema/CategoryData.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CategoryData.CategoryNode" {
  const CategoryNode:any;
  export default CategoryNode;
}
declare module "@salesforce/schema/CategoryData.CategoryNodeId" {
  const CategoryNodeId:any;
  export default CategoryNodeId;
}
declare module "@salesforce/schema/CategoryData.RelatedSobject" {
  const RelatedSobject:any;
  export default RelatedSobject;
}
declare module "@salesforce/schema/CategoryData.RelatedSobjectId" {
  const RelatedSobjectId:any;
  export default RelatedSobjectId;
}
declare module "@salesforce/schema/CategoryData.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/CategoryData.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CategoryData.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CategoryData.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CategoryData.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/CategoryData.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/CategoryData.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/CategoryData.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
