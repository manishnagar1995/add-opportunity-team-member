declare module "@salesforce/schema/CaseTeamTemplate.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CaseTeamTemplate.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/CaseTeamTemplate.Description" {
  const Description:string;
  export default Description;
}
declare module "@salesforce/schema/CaseTeamTemplate.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CaseTeamTemplate.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CaseTeamTemplate.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CaseTeamTemplate.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/CaseTeamTemplate.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/CaseTeamTemplate.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/CaseTeamTemplate.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
