declare module "@salesforce/schema/Calendar.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/Calendar.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/Calendar.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/Calendar.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/Calendar.Type" {
  const Type:string;
  export default Type;
}
declare module "@salesforce/schema/Calendar.IsActive" {
  const IsActive:boolean;
  export default IsActive;
}
declare module "@salesforce/schema/Calendar.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/Calendar.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/Calendar.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/Calendar.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/Calendar.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/Calendar.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/Calendar.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
