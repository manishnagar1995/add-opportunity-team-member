declare module "@salesforce/schema/ContentBody.Id" {
  const Id:any;
  export default Id;
}
