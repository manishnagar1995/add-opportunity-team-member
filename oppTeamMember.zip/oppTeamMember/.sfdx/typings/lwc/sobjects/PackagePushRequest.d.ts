declare module "@salesforce/schema/PackagePushRequest.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/PackagePushRequest.PackageVersion" {
  const PackageVersion:any;
  export default PackageVersion;
}
declare module "@salesforce/schema/PackagePushRequest.PackageVersionId" {
  const PackageVersionId:any;
  export default PackageVersionId;
}
declare module "@salesforce/schema/PackagePushRequest.ScheduledStartTime" {
  const ScheduledStartTime:any;
  export default ScheduledStartTime;
}
declare module "@salesforce/schema/PackagePushRequest.Status" {
  const Status:string;
  export default Status;
}
declare module "@salesforce/schema/PackagePushRequest.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
