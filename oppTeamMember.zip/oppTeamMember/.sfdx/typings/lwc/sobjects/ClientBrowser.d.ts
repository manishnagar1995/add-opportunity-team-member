declare module "@salesforce/schema/ClientBrowser.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ClientBrowser.Users" {
  const Users:any;
  export default Users;
}
declare module "@salesforce/schema/ClientBrowser.UsersId" {
  const UsersId:any;
  export default UsersId;
}
declare module "@salesforce/schema/ClientBrowser.FullUserAgent" {
  const FullUserAgent:string;
  export default FullUserAgent;
}
declare module "@salesforce/schema/ClientBrowser.ProxyInfo" {
  const ProxyInfo:string;
  export default ProxyInfo;
}
declare module "@salesforce/schema/ClientBrowser.LastUpdate" {
  const LastUpdate:any;
  export default LastUpdate;
}
declare module "@salesforce/schema/ClientBrowser.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
