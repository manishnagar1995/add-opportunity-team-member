declare module "@salesforce/schema/DataStatistics.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/DataStatistics.ExternalId" {
  const ExternalId:string;
  export default ExternalId;
}
declare module "@salesforce/schema/DataStatistics.StatType" {
  const StatType:string;
  export default StatType;
}
declare module "@salesforce/schema/DataStatistics.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/DataStatistics.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/DataStatistics.Type" {
  const Type:string;
  export default Type;
}
declare module "@salesforce/schema/DataStatistics.StatValue" {
  const StatValue:number;
  export default StatValue;
}
