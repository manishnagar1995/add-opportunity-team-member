declare module "@salesforce/schema/job_Position__c.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/job_Position__c.Owner" {
  const Owner:any;
  export default Owner;
}
declare module "@salesforce/schema/job_Position__c.OwnerId" {
  const OwnerId:any;
  export default OwnerId;
}
declare module "@salesforce/schema/job_Position__c.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/job_Position__c.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/job_Position__c.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/job_Position__c.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/job_Position__c.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/job_Position__c.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/job_Position__c.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/job_Position__c.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/job_Position__c.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/job_Position__c.LastViewedDate" {
  const LastViewedDate:any;
  export default LastViewedDate;
}
declare module "@salesforce/schema/job_Position__c.LastReferencedDate" {
  const LastReferencedDate:any;
  export default LastReferencedDate;
}
declare module "@salesforce/schema/job_Position__c.Job_id__c" {
  const Job_id__c:string;
  export default Job_id__c;
}
declare module "@salesforce/schema/job_Position__c.job_experience_in_years__c" {
  const job_experience_in_years__c:number;
  export default job_experience_in_years__c;
}
declare module "@salesforce/schema/job_Position__c.Closing_date__c" {
  const Closing_date__c:any;
  export default Closing_date__c;
}
