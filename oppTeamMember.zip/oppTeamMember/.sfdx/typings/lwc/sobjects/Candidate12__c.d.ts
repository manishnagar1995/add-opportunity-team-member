declare module "@salesforce/schema/Candidate12__c.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/Candidate12__c.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/Candidate12__c.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/Candidate12__c.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/Candidate12__c.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/Candidate12__c.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/Candidate12__c.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/Candidate12__c.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/Candidate12__c.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/Candidate12__c.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/Candidate12__c.LastViewedDate" {
  const LastViewedDate:any;
  export default LastViewedDate;
}
declare module "@salesforce/schema/Candidate12__c.LastReferencedDate" {
  const LastReferencedDate:any;
  export default LastReferencedDate;
}
declare module "@salesforce/schema/Candidate12__c.Candidate_SSN__c" {
  const Candidate_SSN__c:string;
  export default Candidate_SSN__c;
}
declare module "@salesforce/schema/Candidate12__c.Postal_Code__c" {
  const Postal_Code__c:number;
  export default Postal_Code__c;
}
declare module "@salesforce/schema/Candidate12__c.Country__c" {
  const Country__c:string;
  export default Country__c;
}
declare module "@salesforce/schema/Candidate12__c.States__c" {
  const States__c:string;
  export default States__c;
}
declare module "@salesforce/schema/Candidate12__c.Position_workflow_candidate__r" {
  const Position_workflow_candidate__r:any;
  export default Position_workflow_candidate__r;
}
declare module "@salesforce/schema/Candidate12__c.Position_workflow_candidate__c" {
  const Position_workflow_candidate__c:any;
  export default Position_workflow_candidate__c;
}
