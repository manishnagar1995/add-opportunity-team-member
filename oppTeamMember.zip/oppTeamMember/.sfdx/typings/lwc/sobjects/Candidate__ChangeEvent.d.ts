declare module "@salesforce/schema/Candidate__ChangeEvent.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.ReplayId" {
  const ReplayId:string;
  export default ReplayId;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.ChangeEventHeader" {
  const ChangeEventHeader:any;
  export default ChangeEventHeader;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.City__c" {
  const City__c:string;
  export default City__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Country__c" {
  const Country__c:string;
  export default Country__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Current_Employer__c" {
  const Current_Employer__c:string;
  export default Current_Employer__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Currently_Employed__c" {
  const Currently_Employed__c:boolean;
  export default Currently_Employed__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Education__c" {
  const Education__c:string;
  export default Education__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Email__c" {
  const Email__c:string;
  export default Email__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.First_Name__c" {
  const First_Name__c:string;
  export default First_Name__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Last_Name__c" {
  const Last_Name__c:string;
  export default Last_Name__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Legacy_Candidate_Number__c" {
  const Legacy_Candidate_Number__c:string;
  export default Legacy_Candidate_Number__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Mobile__c" {
  const Mobile__c:string;
  export default Mobile__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Phone__c" {
  const Phone__c:string;
  export default Phone__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.State_Province__c" {
  const State_Province__c:string;
  export default State_Province__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Street_Address_1__c" {
  const Street_Address_1__c:string;
  export default Street_Address_1__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Street_Address_2__c" {
  const Street_Address_2__c:string;
  export default Street_Address_2__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Years_of_Experience__c" {
  const Years_of_Experience__c:number;
  export default Years_of_Experience__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Zip_Postal_Code__c" {
  const Zip_Postal_Code__c:string;
  export default Zip_Postal_Code__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Position_Candidate__c" {
  const Position_Candidate__c:any;
  export default Position_Candidate__c;
}
declare module "@salesforce/schema/Candidate__ChangeEvent.Status__c" {
  const Status__c:string;
  export default Status__c;
}
