declare module "@salesforce/schema/CollaborationGroupMember.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CollaborationGroupMember.CollaborationGroup" {
  const CollaborationGroup:any;
  export default CollaborationGroup;
}
declare module "@salesforce/schema/CollaborationGroupMember.CollaborationGroupId" {
  const CollaborationGroupId:any;
  export default CollaborationGroupId;
}
declare module "@salesforce/schema/CollaborationGroupMember.Member" {
  const Member:any;
  export default Member;
}
declare module "@salesforce/schema/CollaborationGroupMember.MemberId" {
  const MemberId:any;
  export default MemberId;
}
declare module "@salesforce/schema/CollaborationGroupMember.CollaborationRole" {
  const CollaborationRole:string;
  export default CollaborationRole;
}
declare module "@salesforce/schema/CollaborationGroupMember.NotificationFrequency" {
  const NotificationFrequency:string;
  export default NotificationFrequency;
}
declare module "@salesforce/schema/CollaborationGroupMember.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CollaborationGroupMember.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CollaborationGroupMember.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CollaborationGroupMember.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/CollaborationGroupMember.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/CollaborationGroupMember.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/CollaborationGroupMember.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/CollaborationGroupMember.LastFeedAccessDate" {
  const LastFeedAccessDate:any;
  export default LastFeedAccessDate;
}
