declare module "@salesforce/schema/DashboardComponent.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/DashboardComponent.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/DashboardComponent.Dashboard" {
  const Dashboard:any;
  export default Dashboard;
}
declare module "@salesforce/schema/DashboardComponent.DashboardId" {
  const DashboardId:any;
  export default DashboardId;
}
declare module "@salesforce/schema/DashboardComponent.CustomReport" {
  const CustomReport:any;
  export default CustomReport;
}
declare module "@salesforce/schema/DashboardComponent.CustomReportId" {
  const CustomReportId:any;
  export default CustomReportId;
}
