declare module "@salesforce/schema/AppTabMember.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/AppTabMember.DurableId" {
  const DurableId:string;
  export default DurableId;
}
declare module "@salesforce/schema/AppTabMember.AppDefinition" {
  const AppDefinition:any;
  export default AppDefinition;
}
declare module "@salesforce/schema/AppTabMember.AppDefinitionId" {
  const AppDefinitionId:any;
  export default AppDefinitionId;
}
declare module "@salesforce/schema/AppTabMember.TabDefinition" {
  const TabDefinition:any;
  export default TabDefinition;
}
declare module "@salesforce/schema/AppTabMember.TabDefinitionId" {
  const TabDefinitionId:any;
  export default TabDefinitionId;
}
declare module "@salesforce/schema/AppTabMember.SortOrder" {
  const SortOrder:number;
  export default SortOrder;
}
declare module "@salesforce/schema/AppTabMember.WorkspaceDriverField" {
  const WorkspaceDriverField:string;
  export default WorkspaceDriverField;
}
