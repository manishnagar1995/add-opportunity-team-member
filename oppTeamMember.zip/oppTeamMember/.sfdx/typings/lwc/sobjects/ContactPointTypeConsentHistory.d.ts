declare module "@salesforce/schema/ContactPointTypeConsentHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContactPointTypeConsentHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ContactPointTypeConsentHistory.ContactPointTypeConsent" {
  const ContactPointTypeConsent:any;
  export default ContactPointTypeConsent;
}
declare module "@salesforce/schema/ContactPointTypeConsentHistory.ContactPointTypeConsentId" {
  const ContactPointTypeConsentId:any;
  export default ContactPointTypeConsentId;
}
declare module "@salesforce/schema/ContactPointTypeConsentHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ContactPointTypeConsentHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ContactPointTypeConsentHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ContactPointTypeConsentHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/ContactPointTypeConsentHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/ContactPointTypeConsentHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
