declare module "@salesforce/schema/ListEmailIndividualRecipient.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.ListEmail" {
  const ListEmail:any;
  export default ListEmail;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.ListEmailId" {
  const ListEmailId:any;
  export default ListEmailId;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.Recipient" {
  const Recipient:any;
  export default Recipient;
}
declare module "@salesforce/schema/ListEmailIndividualRecipient.RecipientId" {
  const RecipientId:any;
  export default RecipientId;
}
