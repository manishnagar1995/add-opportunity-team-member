declare module "@salesforce/schema/AuthorizationFormHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/AuthorizationFormHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/AuthorizationFormHistory.AuthorizationForm" {
  const AuthorizationForm:any;
  export default AuthorizationForm;
}
declare module "@salesforce/schema/AuthorizationFormHistory.AuthorizationFormId" {
  const AuthorizationFormId:any;
  export default AuthorizationFormId;
}
declare module "@salesforce/schema/AuthorizationFormHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/AuthorizationFormHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/AuthorizationFormHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/AuthorizationFormHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/AuthorizationFormHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/AuthorizationFormHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
