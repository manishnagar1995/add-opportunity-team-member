declare module "@salesforce/schema/CollaborationGroupRecord.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CollaborationGroupRecord.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/CollaborationGroupRecord.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CollaborationGroupRecord.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CollaborationGroupRecord.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CollaborationGroupRecord.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/CollaborationGroupRecord.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/CollaborationGroupRecord.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/CollaborationGroupRecord.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/CollaborationGroupRecord.CollaborationGroup" {
  const CollaborationGroup:any;
  export default CollaborationGroup;
}
declare module "@salesforce/schema/CollaborationGroupRecord.CollaborationGroupId" {
  const CollaborationGroupId:any;
  export default CollaborationGroupId;
}
declare module "@salesforce/schema/CollaborationGroupRecord.Record" {
  const Record:any;
  export default Record;
}
declare module "@salesforce/schema/CollaborationGroupRecord.RecordId" {
  const RecordId:any;
  export default RecordId;
}
