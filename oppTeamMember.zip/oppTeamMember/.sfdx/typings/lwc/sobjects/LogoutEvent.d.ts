declare module "@salesforce/schema/LogoutEvent.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/LogoutEvent.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/LogoutEvent.EventIdentifier" {
  const EventIdentifier:string;
  export default EventIdentifier;
}
declare module "@salesforce/schema/LogoutEvent.User" {
  const User:any;
  export default User;
}
declare module "@salesforce/schema/LogoutEvent.UserId" {
  const UserId:any;
  export default UserId;
}
declare module "@salesforce/schema/LogoutEvent.Username" {
  const Username:string;
  export default Username;
}
declare module "@salesforce/schema/LogoutEvent.EventDate" {
  const EventDate:any;
  export default EventDate;
}
declare module "@salesforce/schema/LogoutEvent.SessionKey" {
  const SessionKey:string;
  export default SessionKey;
}
declare module "@salesforce/schema/LogoutEvent.LoginKey" {
  const LoginKey:string;
  export default LoginKey;
}
declare module "@salesforce/schema/LogoutEvent.SessionLevel" {
  const SessionLevel:string;
  export default SessionLevel;
}
declare module "@salesforce/schema/LogoutEvent.SourceIp" {
  const SourceIp:string;
  export default SourceIp;
}
