declare module "@salesforce/schema/emp__ChangeEvent.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/emp__ChangeEvent.ReplayId" {
  const ReplayId:string;
  export default ReplayId;
}
declare module "@salesforce/schema/emp__ChangeEvent.ChangeEventHeader" {
  const ChangeEventHeader:any;
  export default ChangeEventHeader;
}
declare module "@salesforce/schema/emp__ChangeEvent.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/emp__ChangeEvent.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/emp__ChangeEvent.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/emp__ChangeEvent.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/emp__ChangeEvent.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/emp__ChangeEvent.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/emp__ChangeEvent.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/emp__ChangeEvent.deptt__c" {
  const deptt__c:any;
  export default deptt__c;
}
declare module "@salesforce/schema/emp__ChangeEvent.ctc__c" {
  const ctc__c:number;
  export default ctc__c;
}
