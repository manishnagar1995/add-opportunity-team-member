declare module "@salesforce/schema/CollaborationGroupMemberRequest.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.CollaborationGroup" {
  const CollaborationGroup:any;
  export default CollaborationGroup;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.CollaborationGroupId" {
  const CollaborationGroupId:any;
  export default CollaborationGroupId;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.Requester" {
  const Requester:any;
  export default Requester;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.RequesterId" {
  const RequesterId:any;
  export default RequesterId;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.ResponseMessage" {
  const ResponseMessage:string;
  export default ResponseMessage;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.Status" {
  const Status:string;
  export default Status;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/CollaborationGroupMemberRequest.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
