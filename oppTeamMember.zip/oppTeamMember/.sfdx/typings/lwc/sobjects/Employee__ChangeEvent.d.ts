declare module "@salesforce/schema/Employee__ChangeEvent.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/Employee__ChangeEvent.ReplayId" {
  const ReplayId:string;
  export default ReplayId;
}
declare module "@salesforce/schema/Employee__ChangeEvent.ChangeEventHeader" {
  const ChangeEventHeader:any;
  export default ChangeEventHeader;
}
declare module "@salesforce/schema/Employee__ChangeEvent.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/Employee__ChangeEvent.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/Employee__ChangeEvent.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/Employee__ChangeEvent.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/Employee__ChangeEvent.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/Employee__ChangeEvent.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/Employee__ChangeEvent.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/Employee__ChangeEvent.Salary__c" {
  const Salary__c:number;
  export default Salary__c;
}
declare module "@salesforce/schema/Employee__ChangeEvent.Department__c" {
  const Department__c:any;
  export default Department__c;
}
declare module "@salesforce/schema/Employee__ChangeEvent.Head_employee__c" {
  const Head_employee__c:any;
  export default Head_employee__c;
}
declare module "@salesforce/schema/Employee__ChangeEvent.Date_of_Joining__c" {
  const Date_of_Joining__c:any;
  export default Date_of_Joining__c;
}
