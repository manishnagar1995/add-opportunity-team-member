declare module "@salesforce/schema/IconDefinition.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/IconDefinition.DurableId" {
  const DurableId:string;
  export default DurableId;
}
declare module "@salesforce/schema/IconDefinition.TabDefinition" {
  const TabDefinition:any;
  export default TabDefinition;
}
declare module "@salesforce/schema/IconDefinition.TabDefinitionId" {
  const TabDefinitionId:any;
  export default TabDefinitionId;
}
declare module "@salesforce/schema/IconDefinition.Url" {
  const Url:string;
  export default Url;
}
declare module "@salesforce/schema/IconDefinition.ContentType" {
  const ContentType:string;
  export default ContentType;
}
declare module "@salesforce/schema/IconDefinition.Theme" {
  const Theme:string;
  export default Theme;
}
declare module "@salesforce/schema/IconDefinition.Height" {
  const Height:number;
  export default Height;
}
declare module "@salesforce/schema/IconDefinition.Width" {
  const Width:number;
  export default Width;
}
