declare module "@salesforce/schema/FeedPollVote.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/FeedPollVote.FeedItem" {
  const FeedItem:any;
  export default FeedItem;
}
declare module "@salesforce/schema/FeedPollVote.FeedItemId" {
  const FeedItemId:any;
  export default FeedItemId;
}
declare module "@salesforce/schema/FeedPollVote.Choice" {
  const Choice:any;
  export default Choice;
}
declare module "@salesforce/schema/FeedPollVote.ChoiceId" {
  const ChoiceId:any;
  export default ChoiceId;
}
declare module "@salesforce/schema/FeedPollVote.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/FeedPollVote.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/FeedPollVote.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/FeedPollVote.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/FeedPollVote.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
