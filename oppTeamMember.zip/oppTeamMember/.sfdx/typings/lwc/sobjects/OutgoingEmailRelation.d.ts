declare module "@salesforce/schema/OutgoingEmailRelation.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/OutgoingEmailRelation.ExternalId" {
  const ExternalId:string;
  export default ExternalId;
}
declare module "@salesforce/schema/OutgoingEmailRelation.OutgoingEmail" {
  const OutgoingEmail:any;
  export default OutgoingEmail;
}
declare module "@salesforce/schema/OutgoingEmailRelation.OutgoingEmailId" {
  const OutgoingEmailId:any;
  export default OutgoingEmailId;
}
declare module "@salesforce/schema/OutgoingEmailRelation.Relation" {
  const Relation:any;
  export default Relation;
}
declare module "@salesforce/schema/OutgoingEmailRelation.RelationId" {
  const RelationId:any;
  export default RelationId;
}
declare module "@salesforce/schema/OutgoingEmailRelation.RelationAddress" {
  const RelationAddress:string;
  export default RelationAddress;
}
