declare module "@salesforce/schema/GroupMember.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/GroupMember.Group" {
  const Group:any;
  export default Group;
}
declare module "@salesforce/schema/GroupMember.GroupId" {
  const GroupId:any;
  export default GroupId;
}
declare module "@salesforce/schema/GroupMember.UserOrGroup" {
  const UserOrGroup:any;
  export default UserOrGroup;
}
declare module "@salesforce/schema/GroupMember.UserOrGroupId" {
  const UserOrGroupId:any;
  export default UserOrGroupId;
}
declare module "@salesforce/schema/GroupMember.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
