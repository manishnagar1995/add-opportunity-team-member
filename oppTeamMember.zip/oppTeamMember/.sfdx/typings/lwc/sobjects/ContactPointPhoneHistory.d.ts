declare module "@salesforce/schema/ContactPointPhoneHistory.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContactPointPhoneHistory.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ContactPointPhoneHistory.ContactPointPhone" {
  const ContactPointPhone:any;
  export default ContactPointPhone;
}
declare module "@salesforce/schema/ContactPointPhoneHistory.ContactPointPhoneId" {
  const ContactPointPhoneId:any;
  export default ContactPointPhoneId;
}
declare module "@salesforce/schema/ContactPointPhoneHistory.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/ContactPointPhoneHistory.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/ContactPointPhoneHistory.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/ContactPointPhoneHistory.Field" {
  const Field:string;
  export default Field;
}
declare module "@salesforce/schema/ContactPointPhoneHistory.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/ContactPointPhoneHistory.NewValue" {
  const NewValue:any;
  export default NewValue;
}
