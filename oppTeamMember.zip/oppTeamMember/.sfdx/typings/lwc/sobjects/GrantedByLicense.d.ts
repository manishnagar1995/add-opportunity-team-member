declare module "@salesforce/schema/GrantedByLicense.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/GrantedByLicense.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/GrantedByLicense.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/GrantedByLicense.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/GrantedByLicense.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/GrantedByLicense.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/GrantedByLicense.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/GrantedByLicense.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/GrantedByLicense.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/GrantedByLicense.PermissionSetLicense" {
  const PermissionSetLicense:any;
  export default PermissionSetLicense;
}
declare module "@salesforce/schema/GrantedByLicense.PermissionSetLicenseId" {
  const PermissionSetLicenseId:any;
  export default PermissionSetLicenseId;
}
declare module "@salesforce/schema/GrantedByLicense.CustomPermission" {
  const CustomPermission:any;
  export default CustomPermission;
}
declare module "@salesforce/schema/GrantedByLicense.CustomPermissionId" {
  const CustomPermissionId:any;
  export default CustomPermissionId;
}
