declare module "@salesforce/schema/emp__c.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/emp__c.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/emp__c.Name" {
  const Name:string;
  export default Name;
}
declare module "@salesforce/schema/emp__c.CreatedDate" {
  const CreatedDate:any;
  export default CreatedDate;
}
declare module "@salesforce/schema/emp__c.CreatedBy" {
  const CreatedBy:any;
  export default CreatedBy;
}
declare module "@salesforce/schema/emp__c.CreatedById" {
  const CreatedById:any;
  export default CreatedById;
}
declare module "@salesforce/schema/emp__c.LastModifiedDate" {
  const LastModifiedDate:any;
  export default LastModifiedDate;
}
declare module "@salesforce/schema/emp__c.LastModifiedBy" {
  const LastModifiedBy:any;
  export default LastModifiedBy;
}
declare module "@salesforce/schema/emp__c.LastModifiedById" {
  const LastModifiedById:any;
  export default LastModifiedById;
}
declare module "@salesforce/schema/emp__c.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/emp__c.LastViewedDate" {
  const LastViewedDate:any;
  export default LastViewedDate;
}
declare module "@salesforce/schema/emp__c.LastReferencedDate" {
  const LastReferencedDate:any;
  export default LastReferencedDate;
}
declare module "@salesforce/schema/emp__c.deptt__r" {
  const deptt__r:any;
  export default deptt__r;
}
declare module "@salesforce/schema/emp__c.deptt__c" {
  const deptt__c:any;
  export default deptt__c;
}
declare module "@salesforce/schema/emp__c.ctc__c" {
  const ctc__c:number;
  export default ctc__c;
}
