declare module "@salesforce/schema/ContentDocumentLink.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/ContentDocumentLink.LinkedEntity" {
  const LinkedEntity:any;
  export default LinkedEntity;
}
declare module "@salesforce/schema/ContentDocumentLink.LinkedEntityId" {
  const LinkedEntityId:any;
  export default LinkedEntityId;
}
declare module "@salesforce/schema/ContentDocumentLink.ContentDocument" {
  const ContentDocument:any;
  export default ContentDocument;
}
declare module "@salesforce/schema/ContentDocumentLink.ContentDocumentId" {
  const ContentDocumentId:any;
  export default ContentDocumentId;
}
declare module "@salesforce/schema/ContentDocumentLink.IsDeleted" {
  const IsDeleted:boolean;
  export default IsDeleted;
}
declare module "@salesforce/schema/ContentDocumentLink.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
declare module "@salesforce/schema/ContentDocumentLink.ShareType" {
  const ShareType:string;
  export default ShareType;
}
declare module "@salesforce/schema/ContentDocumentLink.Visibility" {
  const Visibility:string;
  export default Visibility;
}
