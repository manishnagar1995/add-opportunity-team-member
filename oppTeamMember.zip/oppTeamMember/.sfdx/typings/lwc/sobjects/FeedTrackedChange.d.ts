declare module "@salesforce/schema/FeedTrackedChange.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/FeedTrackedChange.FeedItem" {
  const FeedItem:any;
  export default FeedItem;
}
declare module "@salesforce/schema/FeedTrackedChange.FeedItemId" {
  const FeedItemId:any;
  export default FeedItemId;
}
declare module "@salesforce/schema/FeedTrackedChange.FieldName" {
  const FieldName:string;
  export default FieldName;
}
declare module "@salesforce/schema/FeedTrackedChange.OldValue" {
  const OldValue:any;
  export default OldValue;
}
declare module "@salesforce/schema/FeedTrackedChange.NewValue" {
  const NewValue:any;
  export default NewValue;
}
