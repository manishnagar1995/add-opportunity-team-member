declare module "@salesforce/schema/PackagePushJob.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/PackagePushJob.PackagePushRequest" {
  const PackagePushRequest:any;
  export default PackagePushRequest;
}
declare module "@salesforce/schema/PackagePushJob.PackagePushRequestId" {
  const PackagePushRequestId:any;
  export default PackagePushRequestId;
}
declare module "@salesforce/schema/PackagePushJob.SubscriberOrganizationKey" {
  const SubscriberOrganizationKey:string;
  export default SubscriberOrganizationKey;
}
declare module "@salesforce/schema/PackagePushJob.Status" {
  const Status:string;
  export default Status;
}
declare module "@salesforce/schema/PackagePushJob.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
