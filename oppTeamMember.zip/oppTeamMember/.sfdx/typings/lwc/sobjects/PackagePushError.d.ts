declare module "@salesforce/schema/PackagePushError.Id" {
  const Id:any;
  export default Id;
}
declare module "@salesforce/schema/PackagePushError.PackagePushJob" {
  const PackagePushJob:any;
  export default PackagePushJob;
}
declare module "@salesforce/schema/PackagePushError.PackagePushJobId" {
  const PackagePushJobId:any;
  export default PackagePushJobId;
}
declare module "@salesforce/schema/PackagePushError.ErrorMessage" {
  const ErrorMessage:string;
  export default ErrorMessage;
}
declare module "@salesforce/schema/PackagePushError.ErrorDetails" {
  const ErrorDetails:string;
  export default ErrorDetails;
}
declare module "@salesforce/schema/PackagePushError.ErrorTitle" {
  const ErrorTitle:string;
  export default ErrorTitle;
}
declare module "@salesforce/schema/PackagePushError.ErrorSeverity" {
  const ErrorSeverity:string;
  export default ErrorSeverity;
}
declare module "@salesforce/schema/PackagePushError.ErrorType" {
  const ErrorType:string;
  export default ErrorType;
}
declare module "@salesforce/schema/PackagePushError.SystemModstamp" {
  const SystemModstamp:any;
  export default SystemModstamp;
}
