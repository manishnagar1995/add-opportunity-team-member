declare module "@salesforce/apex/oppteamaview.oppteam" {
  export default function oppteam(param: {searchText: any}): Promise<any>;
}
