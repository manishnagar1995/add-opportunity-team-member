declare module "@salesforce/apex/oppteam.total" {
  export default function total(param: {rohit: any}): Promise<any>;
}
declare module "@salesforce/apex/oppteam.dataShow" {
  export default function dataShow(param: {honey: any}): Promise<any>;
}
declare module "@salesforce/apex/oppteam.saveData" {
  export default function saveData(param: {roll: any, xyz: any}): Promise<any>;
}
declare module "@salesforce/apex/oppteam.getteamList" {
  export default function getteamList(): Promise<any>;
}
